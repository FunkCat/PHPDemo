<?php 
 return array(
'_FOLLOWERS_' =>' Pay attention to',
'_SUCCESS_' =>' Success',
'_FAIL_' =>' Failure',
'_PLEASE_' =>' Please',
'_LOG_IN_' =>' Sign in',
'_CANCEL_' =>' Cancel',

);