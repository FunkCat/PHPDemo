<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 15-3-5
 * Time: 下午5:26
 * @author 郑钟良<zzl@ourstu.com>
 */


define('ADDON_NAME','Skin');
define('SKIN_PATH',ONETHINK_ADDON_PATH.'Skin/');
define('USER_CONFIG_MARK_NAME','skin');
define('USER_CONFIG_MARK_MODEL','Addon_Skin');