<?php
return array(
	'name' => '简约风格',
    'sort' => '3'
);